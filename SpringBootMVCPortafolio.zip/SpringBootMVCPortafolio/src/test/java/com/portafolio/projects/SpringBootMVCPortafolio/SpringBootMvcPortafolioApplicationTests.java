package com.portafolio.projects.SpringBootMVCPortafolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMvcPortafolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
