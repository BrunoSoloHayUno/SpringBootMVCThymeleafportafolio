package com.portafolio.projects.SpringBootMVCPortafolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMvcPortafolioApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMvcPortafolioApplication.class, args);
	}

}
